def _identity_fwd(**kwargs):
    return kwargs["out"]
