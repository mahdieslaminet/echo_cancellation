# !/usr/bin/env python
# -*- coding: utf-8 -*-
"""Version info"""

short_version = "1.0"
version = "1.0.0"
